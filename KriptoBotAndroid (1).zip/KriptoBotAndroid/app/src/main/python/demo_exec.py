"""Binance DEMO hesabı emir yürütücüsü. YALNIZCA demo/testnet adreslerine bağlanır; canlı (fapi.binance.com) adresi kodda YOKTUR.
Anahtarlar yalnızca bellekte tutulur, diske yazılmaz, loglanmaz.

SL/TP koruma emirleri Binance'in koşullu emir (Algo) servisine yazılır: bağlantı/uygulama kopsa da Binance korur.
Bu botun koyduğu koşullu emirlerin kimliği "kb" ile başlar; kullanıcının kendi emirlerine dokunulmaz (elle kapatma hariç)."""
import asyncio
import hashlib
import hmac
import json
import time
import urllib.parse
from collections import deque
from decimal import ROUND_DOWN, ROUND_HALF_UP, Decimal

BASES = {"demo": "https://demo-fapi.binance.com", "testnet": "https://testnet.binancefuture.com"}
PREFIX = "kb"


def fmt(x):
    return format(Decimal(str(x)).normalize(), "f")


class Demo:
    def __init__(self):
        self.key = self.secret = None
        self.env = "demo"
        self.connected = False
        self.balance = None
        self.avail = None
        self.hedge = False
        self.offset = 0
        self.err = ""
        self.log = deque(maxlen=60)
        self.lev_set = set()
        self.s = None
        self.use_algo = None          # None: henüz bilinmiyor, True: /fapi/v1/algoOrder, False: eski /fapi/v1/order
        self.pos_cache = {}           # sembol -> borsadaki pozisyon (son senkron)
        self.algo_cache = []          # borsadaki açık koşullu emirler (son senkron)
        self.sync_info = {"ts": 0, "pos": 0, "algo": 0, "err": "", "hist": 0}
        self.lock = asyncio.Lock()

    def forget(self):
        self.key = self.secret = None
        self.connected, self.balance, self.avail, self.err = False, None, None, ""
        self.lev_set.clear()
        self.pos_cache, self.algo_cache = {}, []

    async def _req(self, method, path, signed=True, **params):
        import aiohttp
        if self.s is None:
            self.s = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=15))
        base = BASES[self.env]
        headers = {}
        if signed:
            params["timestamp"] = int(time.time() * 1000) + self.offset
            params["recvWindow"] = 10000
            q = urllib.parse.urlencode(params)
            sig = hmac.new(self.secret.encode(), q.encode(), hashlib.sha256).hexdigest()
            q += "&signature=" + sig
            headers["X-MBX-APIKEY"] = self.key
        else:
            q = urllib.parse.urlencode(params)
        async with self.s.request(method, f"{base}{path}?{q}", headers=headers) as r:
            txt = await r.text()
            if r.status >= 400:
                raise RuntimeError(f"HTTP {r.status}: {txt[:160]}")
            return json.loads(txt)

    async def connect(self, key, secret, env):
        if env not in BASES:
            raise ValueError("Geçersiz ortam")
        self.key, self.secret, self.env = key.strip(), secret.strip(), env
        self.connected = False
        self.use_algo = None
        t = await self._req("GET", "/fapi/v1/time", signed=False)
        self.offset = int(t["serverTime"]) - int(time.time() * 1000)
        try:
            acc = await self._req("GET", "/fapi/v3/account")
        except Exception:
            acc = await self._req("GET", "/fapi/v2/account")
        self.balance = float(acc.get("totalWalletBalance", 0))
        self.avail = float(acc.get("availableBalance", 0))
        try:
            self.hedge = bool((await self._req("GET", "/fapi/v1/positionSide/dual")).get("dualSidePosition"))
        except Exception:
            self.hedge = False
        self.connected, self.err = True, ""
        self.note(f"Bağlandı ({env}), bakiye {self.balance:.2f} USDT" + (", hedge modu" if self.hedge else ""))

    def note(self, msg):
        self.log.appendleft({"t": time.strftime("%H:%M:%S"), "m": msg})

    # ---------- yuvarlama ----------
    @staticmethod
    def fit(qty, flt):
        step = Decimal(str(flt.get("step") or 0))
        q = Decimal(str(qty))
        if step > 0:
            q = (q / step).to_integral_value(rounding=ROUND_DOWN) * step
        return q

    @staticmethod
    def fit_price(px, flt):
        tick = Decimal(str(flt.get("tick") or 0))
        p = Decimal(str(px))
        if tick > 0:
            p = (p / tick).to_integral_value(rounding=ROUND_HALF_UP) * tick
        return format(p.normalize(), "f")

    # ---------- piyasa emirleri ----------
    async def place(self, sym, side, qty, reduce, flt, lev, price):
        """MARKET emir. side = pozisyon yönü (LONG/SHORT); reduce=True ise o pozisyonu azaltır/kapatır."""
        q = self.fit(qty, flt)
        if q <= 0 or float(q) < flt.get("minq", 0) or (not reduce and float(q) * price < flt.get("notional", 5)):
            raise RuntimeError(f"{sym}: miktar borsa limitlerinin altında ({q})")
        if not reduce and sym not in self.lev_set:
            try:
                await self._req("POST", "/fapi/v1/marginType", symbol=sym, marginType="CROSSED")
            except Exception:
                pass            # zaten CROSSED ise hata döner, önemsiz
            await self._req("POST", "/fapi/v1/leverage", symbol=sym, leverage=int(lev))
            self.lev_set.add(sym)
        return await self._market(sym, side, format(q, "f"), reduce)

    async def _market(self, sym, side, qty_str, reduce):
        long = side == "LONG"
        order_side = ("BUY" if long else "SELL") if not reduce else ("SELL" if long else "BUY")
        p = {"symbol": sym, "side": order_side, "type": "MARKET", "quantity": qty_str, "newOrderRespType": "RESULT"}
        if self.hedge:
            p["positionSide"] = "LONG" if long else "SHORT"
        elif reduce:
            p["reduceOnly"] = "true"
        r = await self._req("POST", "/fapi/v1/order", **p)
        self.note(f"{'KAPAT' if reduce else 'AÇ'} {sym} {side} {qty_str} @ {r.get('avgPrice', '?')}")
        return r

    async def close_market(self, sym, side, qty_str):
        """Borsadaki pozisyonu (gerçek miktarıyla) piyasa emriyle kapatır."""
        return await self._market(sym, side, qty_str, True)

    # ---------- koşullu emirler (SL / TP) ----------
    def _cid(self, role, sym):
        return f"{PREFIX}_{role}_{sym[:14]}_{int(time.time() * 1000) % 10**9}"[:36]

    async def conditional(self, sym, pos_side, typ, trigger, flt, qty=None, close=False, role="x", working="CONTRACT_PRICE"):
        """STOP_MARKET / TAKE_PROFIT_MARKET koyar. pos_side: korunan pozisyonun yönü (LONG/SHORT)."""
        side = "SELL" if pos_side == "LONG" else "BUY"
        trig = self.fit_price(trigger, flt)
        cid = self._cid(role, sym)
        qty_s = None
        if not close:
            qq = self.fit(qty, flt)
            if qq <= 0:
                raise RuntimeError(f"{sym}: koşullu emir miktarı 0")
            qty_s = format(qq, "f")
        last = None
        for _ in range(2):
            algo = self.use_algo is not False
            try:
                if algo:
                    b = {"algoType": "CONDITIONAL", "symbol": sym, "side": side, "type": typ, "triggerPrice": trig,
                         "workingType": working, "clientAlgoId": cid}
                    path, key = "/fapi/v1/algoOrder", None
                else:
                    b = {"symbol": sym, "side": side, "type": typ, "stopPrice": trig, "workingType": working,
                         "newClientOrderId": cid}
                    path = "/fapi/v1/order"
                if close:
                    b["closePosition"] = "true"
                else:
                    b["quantity"] = qty_s
                    if not self.hedge:
                        b["reduceOnly"] = "true"
                if self.hedge:
                    b["positionSide"] = pos_side
                r = await self._req("POST", path, **b)
                self.use_algo = algo
                self.note(f"{role.upper()} koyuldu {sym} @ {trig}" + ("" if algo else " (eski uç)"))
                return r
            except RuntimeError as e:
                last = e
                m = str(e)
                if algo and "HTTP 404" in m and self.use_algo is None:
                    self.use_algo = False
                    continue
                if not algo and "-4120" in m:
                    self.use_algo = True
                    continue
                raise
        raise last

    @staticmethod
    def _norm_algo(x):
        """Algo ve eski emir yanıtlarını ortak biçime çevirir."""
        return {"id": x.get("algoId", x.get("orderId")), "cid": x.get("clientAlgoId") or x.get("clientOrderId") or "",
                "sym": x.get("symbol"), "side": x.get("side"),
                "type": x.get("orderType") or x.get("type") or "", "trig": float(x.get("triggerPrice") or x.get("stopPrice") or 0),
                "qty": float(x.get("quantity") or x.get("origQty") or 0),
                "close": str(x.get("closePosition")).lower() == "true", "ps": x.get("positionSide", "BOTH")}

    async def open_algo(self):
        if self.use_algo is not False:
            try:
                r = await self._req("GET", "/fapi/v1/openAlgoOrders")
                arr = r if isinstance(r, list) else (r.get("orders") or r.get("data") or [])
                self.use_algo = True if self.use_algo is None else self.use_algo
                return [self._norm_algo(x) for x in arr]
            except RuntimeError as e:
                if "HTTP 404" not in str(e) or self.use_algo is True:
                    raise
                self.use_algo = False
        arr = await self._req("GET", "/fapi/v1/openOrders")
        return [self._norm_algo(x) for x in arr if str(x.get("type", "")).startswith(("STOP", "TAKE_PROFIT"))]

    async def cancel_algo(self, a):
        if self.use_algo is False:
            return await self._req("DELETE", "/fapi/v1/order", symbol=a["sym"], orderId=a["id"])
        return await self._req("DELETE", "/fapi/v1/algoOrder", algoId=a["id"])

    # ---------- hesap / pozisyon / geçmiş ----------
    async def positions(self):
        try:
            arr = await self._req("GET", "/fapi/v3/positionRisk")
        except Exception:
            arr = await self._req("GET", "/fapi/v2/positionRisk")
        out = {}
        for x in arr:
            raw = str(x.get("positionAmt", "0"))
            amt = float(raw or 0)
            if amt == 0:
                continue
            ps = x.get("positionSide", "BOTH")
            side = "LONG" if (ps == "LONG" or (ps == "BOTH" and amt > 0)) else "SHORT"
            sym = x["symbol"]
            if sym in out and abs(amt) <= out[sym]["qty"]:
                continue
            out[sym] = {"symbol": sym, "side": side, "qty": abs(amt), "qty_str": raw.lstrip("-"),
                        "entry": float(x.get("entryPrice") or 0), "mark": float(x.get("markPrice") or 0),
                        "upnl": float(x.get("unRealizedProfit") or 0), "lev": int(float(x.get("leverage") or 0)),
                        "t": int(x.get("updateTime") or 0) / 1000.0, "ps": ps}
        return out

    async def trades(self, sym, start_ms):
        return await self._req("GET", "/fapi/v1/userTrades", symbol=sym, startTime=int(start_ms), limit=1000)

    async def income_symbols(self, days=7):
        start = int((time.time() - days * 86400) * 1000) + self.offset
        arr = await self._req("GET", "/fapi/v1/income", incomeType="REALIZED_PNL", startTime=start, limit=1000)
        syms = {}
        for x in arr:
            if x.get("symbol"):
                syms[x["symbol"]] = max(syms.get(x["symbol"], 0), int(x.get("time", 0)))
        return sorted(syms, key=lambda s: -syms[s])

    async def refresh_balance(self):
        try:
            try:
                acc = await self._req("GET", "/fapi/v3/account")
            except Exception:
                acc = await self._req("GET", "/fapi/v2/account")
            self.balance, self.avail = float(acc["totalWalletBalance"]), float(acc["availableBalance"])
        except Exception as e:
            self.err = str(e)[:120]
