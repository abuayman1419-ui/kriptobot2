"""Kullanıcının panelden değiştirebildiği işlem parametreleri (anahtarlar burada TUTULMAZ)."""
import json
import os

# key, etiket, yardım, min, max, adım, ölçek(1=olduğu gibi, 100=oran->yüzde), tamsayı
FIELDS = [
    ("leverage", "Kaldıraç (x)", "Pozisyon teminatı = pozisyon büyüklüğü / kaldıraç", 1, 20, 1, 1, True),
    ("margin_pct", "Marjin: işlem başına en çok (% bakiye)", "Tek işlemde teminat olarak ayrılabilecek en yüksek bakiye oranı", 1, 100, 1, 100, False),
    ("risk_pct", "İşlem başı risk (% bakiye)", "Stop Loss olursa kaybedilecek bakiye oranı; pozisyon büyüklüğünü bu belirler", 0.1, 10, 0.1, 100, False),
    ("max_positions", "Aynı anda en fazla işlem", "Açık pozisyon sınırı", 1, 10, 1, 1, True),
    ("entry_threshold", "Minimum sinyal puanı (risk puanı eşiği)", "Bu puanın altındaki fırsatlar için işlem açılmaz (100 üzerinden)", 50, 100, 1, 1, False),
    ("opposite_max", "Karşı yön puanı üst sınırı", "Karşı yön puanı bunun üstündeyse sinyal belirsiz sayılır", 20, 80, 1, 1, False),
    ("sl_atr_mult", "Stop Loss mesafesi (ATR katı)", "Küçük değer = dar stop, sık tetiklenir", 0.5, 5, 0.1, 1, False),
    ("tp_r1", "TP1 (R katı)", "R = stop mesafesi", 0.3, 10, 0.1, 1, False),
    ("tp_r2", "TP2 (R katı)", "", 0.3, 10, 0.1, 1, False),
    ("tp_r3", "TP3 (R katı)", "", 0.3, 20, 0.1, 1, False),
    ("split1", "TP1'de kapatılacak pay (%)", "Kalan pay TP2 ve TP3 arasında bölünür", 5, 95, 5, 1, False),
    ("split2", "TP2'de kapatılacak pay (%)", "TP3 payı = 100 - TP1 - TP2", 0, 95, 5, 1, False),
    ("max_hold_minutes", "Azami işlem süresi (dk)", "Süre dolunca pozisyon kapatılır", 5, 1440, 5, 1, True),
    ("daily_loss_pct", "Günlük zarar limiti (% bakiye)", "Aşılırsa gün sonuna kadar yeni işlem açılmaz", 1, 50, 1, 100, False),
    ("max_consec_losses", "Üst üste zarar sınırı", "Bu kadar zarar sonrası bekleme başlar", 1, 10, 1, 1, True),
    ("cooldown_minutes", "Bekleme süresi (dk)", "", 0, 240, 5, 1, True),
    ("start_balance", "Sanal başlangıç bakiyesi (USDT)", "Yalnızca 'Sanal hesabı sıfırla' ile uygulanır", 10, 1_000_000, 10, 1, False),
]
PATH = os.path.join("logs", "settings.json")


def get_values(cfg):
    v = {}
    for k, *_ in FIELDS:
        if k.startswith("tp_r"):
            x = cfg.tp_r[int(k[-1]) - 1]
        elif k == "split1":
            x = cfg.tp_split[0] * 100
        elif k == "split2":
            x = cfg.tp_split[1] * 100
        else:
            x = getattr(cfg, k)
            sc = next(f[6] for f in FIELDS if f[0] == k)
            x = x * sc
        v[k] = round(float(x), 4)
    return v


def apply(cfg, vals):
    """Doğrular, sınırlar içine alır ve cfg'ye uygular. Hata metinlerini döndürür."""
    errs, cur = [], get_values(cfg)
    for k, lab, _, lo, hi, _, sc, isint in FIELDS:
        if k not in vals:
            continue
        try:
            x = float(vals[k])
        except Exception:
            errs.append(f"{lab}: sayı değil")
            continue
        cur[k] = max(lo, min(hi, x))
    if not (cur["tp_r1"] < cur["tp_r2"] < cur["tp_r3"]):
        errs.append("TP1 < TP2 < TP3 olmalı")
    if cur["split1"] + cur["split2"] > 100:
        errs.append("TP1 + TP2 payı 100'ü aşamaz")
    if errs:
        return errs
    for k, lab, _, lo, hi, _, sc, isint in FIELDS:
        if k.startswith("tp_r") or k.startswith("split"):
            continue
        x = cur[k] / sc
        setattr(cfg, k, int(round(x)) if isint else x)
    cfg.tp_r = (cur["tp_r1"], cur["tp_r2"], cur["tp_r3"])
    cfg.tp_split = (cur["split1"] / 100, cur["split2"] / 100, round(1 - cur["split1"] / 100 - cur["split2"] / 100, 4))
    return []


def save(cfg):
    os.makedirs("logs", exist_ok=True)
    with open(PATH, "w", encoding="utf-8") as fh:
        json.dump(get_values(cfg), fh)


def load(cfg):
    try:
        with open(PATH, encoding="utf-8") as fh:
            apply(cfg, json.load(fh))
    except Exception:
        pass


def schema():
    return [{"key": k, "label": l, "help": h, "min": lo, "max": hi, "step": st, "int": i}
            for k, l, h, lo, hi, st, sc, i in FIELDS]
