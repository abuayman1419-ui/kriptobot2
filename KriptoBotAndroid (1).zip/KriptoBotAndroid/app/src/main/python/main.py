"""CRYPTO AI TERMINAL - PAPER modu. Çalıştır:  python backend/main.py   ->  http://localhost:8000"""
import asyncio
import os
import sys
import time
import traceback
from contextlib import asynccontextmanager

sys.path.insert(0, os.path.dirname(__file__))
import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse

from auth import LOGIN_HTML, MIN_LEN, Auth, is_loopback, local_ip
from binance_api import Futures, Stream, rows_to_df
import insight
import settings
from config import CFG
from demo_exec import Demo
from exchange_sync import ExchangeSync
from news import NewsFeed
from paper_engine import PaperEngine
from scoring import analyze, btc_bias, regime
from util import clean

# --- Erişim ayarları (ortam değişkenleri) ---
HOST = os.environ.get("TERMINAL_HOST", "127.0.0.1")        # telefon için 0.0.0.0
PORT = int(os.environ.get("PORT") or os.environ.get("TERMINAL_PORT") or 8000)
PIN = os.environ.get("TERMINAL_PIN", "")                    # ağdan erişimde ZORUNLU
TRUST_PROXY = os.environ.get("TERMINAL_TRUST_PROXY") == "1"  # tünel / ters vekil arkasında
auth = Auth(PIN, os.path.join(CFG.log_dir, "session.key"))

api = Futures()
engine = PaperEngine(CFG)
feed = NewsFeed()
demo = Demo()
settings.load(CFG)
engine.balance = engine.peak = engine.day_start = engine.base = CFG.start_balance
sync = ExchangeSync(engine, demo, api.filters, CFG)
flt_default = {"step": 0.001, "minq": 0.001, "notional": 5}
S = {"status": "Başlıyor...", "opps": [], "regime": "-", "scan_ts": 0, "universe": 0,
     "errors": [], "scan_ms": 0, "scan_note": "", "rest_fallback": 0}
stream = None
qv24 = {}
sem = asyncio.Semaphore(8)
BG = set()          # görev referansları (çöp toplayıcı görevleri öldürmesin)
LAST_GOOD = {}


def spawn(coro):
    t = asyncio.create_task(coro)
    BG.add(t)
    t.add_done_callback(BG.discard)
    return t


def log_err(where):
    line = traceback.format_exc(limit=3).strip().splitlines()[-1]
    S["errors"] = (S["errors"] + [f"{time.strftime('%H:%M:%S')} {where}: {line}"])[-10:]


async def safe(coro):
    async with sem:
        try:
            return await coro
        except Exception:
            return None


async def reseed(syms):
    async def one(s):
        r = await safe(api.klines(s, "1m", CFG.warmup_candles))
        if r:
            stream.seed(s, r)
    await asyncio.gather(*(one(s) for s in syms))


def prefilter(syms):
    sc, mk = [], []
    for s in syms:
        if stream.age(s) > 90:
            continue
        df = stream.frame(s)
        if df is None or len(df) < 35:
            continue
        c, v = df.c, df.v
        r5 = (c.iloc[-1] / c.iloc[-6] - 1) * 100
        vr = v.iloc[-3:].mean() / max(v.iloc[-30:-3].mean(), 1e-12)
        score = abs(r5) + 0.5 * vr
        sc.append((score, s))
        mk.append((score, s, round(float(r5), 2), round(float(vr), 1)))
    S["market"] = [(s, r5, vr) for _, s, r5, vr in sorted(mk, reverse=True)]   # izlenen TÜM coinler
    return [s for _, s in sorted(sc, reverse=True)[:CFG.deep_n]]


async def deep(sym, funding, b_bias):
    k5, k15, dp, oi = await asyncio.gather(
        safe(api.klines(sym, "5m", 120)), safe(api.klines(sym, "15m", 120)),
        safe(api.depth(sym, 20)), safe(api.oi_change(sym)))
    if not k5 or not k15:
        return None
    try:
        f = {"5m": rows_to_df(k5[:-1]), "15m": rows_to_df(k15[:-1])}   # açık mum atılır
        r = analyze(sym, f, dp, oi, funding.get(sym), b_bias, qv24.get(sym, 0), CFG,
                    news_bias=feed.bias_for(sym), news_flag=feed.critical_for(sym))
        r["news"] = [{"title": i.get("title_tr") or i["title"], "level": i["level"]} for i in feed.for_symbol(sym, 6)[:3]]
        r.update(insight.build(r, f, CFG))
        return r
    except Exception:
        log_err(f"analiz {sym}")
        return None


async def scan_once():
    t0 = time.time()
    # WebSocket gecikmişse REST ile yenile (panel boşalmasın)
    stale = [s for s in stream.symbols if stream.age(s) > 45]
    S["rest_fallback"] = len(stale)
    if stale:
        await reseed(stale)
    b5, b15 = await asyncio.gather(safe(api.klines("BTCUSDT", "5m", 120)), safe(api.klines("BTCUSDT", "15m", 120)))
    if not b5 or not b15:
        S["scan_note"] = "BTC verisi alınamadı (API/ağ). Önceki sonuçlar gösteriliyor."
        return
    d5, d15 = rows_to_df(b5[:-1]), rows_to_df(b15[:-1])
    bb = btc_bias(d5, d15)
    S["regime"], S["btc_bias"] = regime(bb, d5), round(float(bb), 2)
    funding = await safe(api.funding_all()) or {}
    cands = prefilter(stream.symbols)
    if not cands:
        S["scan_note"] = "Taze veri yok; önceki sonuçlar gösteriliyor."
        return
    res = [r for r in await asyncio.gather(*(deep(s, funding, bb) for s in cands)) if r]
    if not res:
        S["scan_note"] = "Analiz üretilemedi (API limiti/hata olabilir). Önceki sonuçlar gösteriliyor."
        return
    res.sort(key=lambda r: -r["score"])
    S["opps"], S["scan_ts"], S["scan_ms"], S["scan_note"] = res, time.time(), int((time.time() - t0) * 1000), ""
    now = time.time()
    for r in res:
        if r["signal"] == "WAIT":
            continue
        px = stream.price.get(r["symbol"])
        if px is None or stream.age(r["symbol"]) > CFG.stale_seconds:
            continue
        ok, why = engine.open(r, px, now)
        r["paper_result"] = "Açıldı" if ok else why


async def scan_loop():
    while True:
        try:
            await scan_once()
        except Exception:
            log_err("tarama")
        await asyncio.sleep(CFG.scan_seconds)


async def mark_loop():
    while True:
        try:
            engine.safe_mode = not stream.healthy()
            for s in list(engine.pos):                      # açık pozisyon fiyatı bayatsa REST'ten al
                if stream.age(s) > CFG.stale_seconds:
                    p = await safe(api.price(s))
                    if p:
                        stream.price[s], stream.ts[s] = p, time.time()
            prices = {s: p for s, p in stream.price.items() if s in engine.pos and stream.age(s) <= CFG.stale_seconds * 3}
            engine.mark(prices, time.time())
            if not engine.eq_hist or time.time() - engine.eq_hist[-1][0] >= 15:
                engine.eq_hist.append((time.time(), round(engine.equity(stream.price), 2)))
            if engine.safe_mode:
                S["status"] = f"WS {stream.connected}/{stream.expected}: yeni işlem kapalı, veri REST ile yenileniyor"
            else:
                S["status"] = f"Canlı veri akışı OK ({engine.mode})"
        except Exception:
            log_err("takip")
        await asyncio.sleep(2)


async def enter_demo():
    """DEMO'ya girerken: bakiyeyi al, Binance'teki pozisyonları motora al, son günlerin işlemlerini çek."""
    engine._paper = (engine.balance, engine.base, engine.peak, engine.day_start)
    await demo.refresh_balance()
    if demo.balance is not None:
        engine.balance = engine.peak = engine.day_start = engine.base = demo.balance
    await sync.reconcile(time.time())
    try:
        await sync.sync_history()
    except Exception as ex:
        demo.note(f"Geçmiş çekilemedi: {str(ex)[:100]}")


async def executor_loop():
    """DEMO modunda emirleri Binance'e gönderir ve Binance ile her ~4 sn senkronlar."""
    last = 0.0
    while True:
        try:
            on = CFG.mode == "DEMO" and demo.connected
            if on and not engine.demo_on:
                engine.demo_on, engine.mode, engine.need_sync, engine.sync_fail = True, "DEMO", True, 0
                try:
                    await enter_demo()
                except Exception as ex:
                    engine.sync_fail += 1
                    demo.sync_info["err"] = str(ex)[:120]
                    log_err("demo giriş")
            elif not on and engine.demo_on:
                engine.demo_on, engine.mode = False, "PAPER"
                engine.queue.clear()
                if getattr(engine, "_paper", None):
                    engine.balance, engine.base, engine.peak, engine.day_start = engine._paper
            if on:
                await sync.process_queue()
                if time.time() - last >= 4:
                    last = time.time()
                    try:
                        await sync.reconcile(time.time())
                    except Exception as ex:
                        engine.sync_fail += 1
                        demo.sync_info["err"] = str(ex)[:120]
                        log_err("senkron")
        except Exception:
            log_err("emir")
        await asyncio.sleep(1)


async def boot():
    global stream, qv24
    try:
        while True:
            try:
                syms, qv24 = await api.universe(CFG)
                break
            except Exception:
                log_err("evren")
                S["status"] = "Binance'e bağlanılamadı, tekrar deneniyor"
                await asyncio.sleep(10)
        feed.universe = {s[:-4] for s in syms}
        S["universe"] = len(syms)
        stream = Stream(syms, CFG)
        S["status"] = f"{len(syms)} sembol için warmup..."
        await reseed(syms)
        stream.start()
        await asyncio.sleep(3)
        spawn(mark_loop())
        spawn(executor_loop())
        spawn(scan_loop())
    except Exception:
        log_err("boot")


@asynccontextmanager
async def lifespan(app):
    spawn(feed.run())
    spawn(boot())
    yield
    await api.close()


app = FastAPI(lifespan=lifespan)
HERE = os.environ.get("TERMINAL_WEB_DIR") or os.path.dirname(__file__)
STATIC = os.path.join(HERE, "static")
# Giriş yapmadan açılabilen yollar (giriş sayfası + uygulama simgeleri)
PUBLIC = {"/login", "/manifest.webmanifest", "/sw.js", "/icon.svg", "/icon-192.png", "/icon-512.png",
          "/apple-touch-icon.png"}
ASSETS = {"/manifest.webmanifest": ("manifest.webmanifest", "application/manifest+json"),
          "/sw.js": ("sw.js", "application/javascript"), "/icon.svg": ("icon.svg", "image/svg+xml"),
          "/icon-192.png": ("icon-192.png", "image/png"), "/icon-512.png": ("icon-512.png", "image/png"),
          "/apple-touch-icon.png": ("apple-touch-icon.png", "image/png")}


@app.middleware("http")
async def gate(request: Request, call_next):
    if not auth.enabled:
        return await call_next(request)
    p = request.url.path
    if p in PUBLIC or auth.valid(request.cookies.get("session")):
        return await call_next(request)
    if p.startswith("/api/"):
        return JSONResponse({"ok": False, "msg": "giriş gerekli"}, status_code=401)
    return RedirectResponse("/login", status_code=303)


def _make_asset(path, fname, mime):
    def h():
        fp = os.path.join(STATIC, fname)
        if not os.path.exists(fp):
            return JSONResponse({"error": "yok"}, status_code=404)
        return FileResponse(fp, media_type=mime, headers={"Cache-Control": "no-cache"})
    app.get(path)(h)


for _p, (_f, _m) in ASSETS.items():
    _make_asset(_p, _f, _m)


@app.get("/login")
def login_page():
    if not auth.enabled:
        return RedirectResponse("/", status_code=303)
    return HTMLResponse(LOGIN_HTML, headers={"Cache-Control": "no-store"})


@app.post("/login")
async def login(req: Request):
    if not _guard(req):
        return JSONResponse({"ok": False, "msg": "yetkisiz"}, status_code=403)
    try:
        pin = str((await req.json()).get("pin", ""))
    except Exception:
        pin = ""
    token, err = auth.login(pin)
    if err:
        return JSONResponse({"ok": False, "msg": err}, status_code=429 if auth.locked() else 401)
    r = JSONResponse({"ok": True})
    https = req.url.scheme == "https" or req.headers.get("x-forwarded-proto") == "https"
    r.set_cookie("session", token, max_age=30 * 86400, httponly=True, samesite="lax", secure=https)
    return r


@app.post("/logout")
async def logout(req: Request):
    if not _guard(req):
        return JSONResponse({"ok": False, "msg": "yetkisiz"}, status_code=403)
    r = JSONResponse({"ok": True})
    r.delete_cookie("session")
    return r


@app.get("/")
def index():
    return FileResponse(os.path.join(HERE, "dashboard.html"), headers={"Cache-Control": "no-cache"})


def by_coin(prices):
    d = {}
    for r in engine.cur_closed():
        c = d.setdefault(r["symbol"], {"symbol": r["symbol"], "trades": 0, "wins": 0, "realized": 0.0, "upnl": 0.0, "open": False})
        c["realized"] += r["pnl"]
        if r["final"]:
            c["trades"] += 1
            c["wins"] += 1 if (r.get("trade_total") or 0) > 0 else 0
    for s, p in engine.pos.items():
        c = d.setdefault(s, {"symbol": s, "trades": 0, "wins": 0, "realized": 0.0, "upnl": 0.0, "open": False})
        c["open"] = True
        c["upnl"] += ((prices.get(s) or p.get("mark") or p["entry"]) - p["entry"]) * p["qty_open"] * p["dir"]
    out = list(d.values())
    for c in out:
        c["realized"], c["upnl"] = round(c["realized"], 3), round(c["upnl"], 3)
        c["total"] = round(c["realized"] + c["upnl"], 3)
    return sorted(out, key=lambda c: -c["total"])


def build_state():
    prices = stream.price if stream else {}
    now = time.time()
    opps = S["opps"]
    def px_of(s, p):
        return prices.get(s) or p.get("mark") or p["entry"]
    pos = [{"symbol": p["symbol"], "side": p["side"], "entry": p["entry"], "price": px_of(s, p),
            "qty_open": p["qty_open"], "sl": p["sl"], "tps": p["tps"], "tp_hit": p["tp_hit"],
            "margin": round(p["margin"], 2), "leverage": p["leverage"], "age_s": int(now - p["opened"]),
            "external": p["external"], "pending": p.get("pending", False), "closing": p.get("closing", False),
            "upnl": round((px_of(s, p) - p["entry"]) * p["qty_open"] * p["dir"], 3)}
           for s, p in engine.pos.items()]
    cur = sorted(engine.cur_closed(), key=lambda r: r["time"])
    mkt = [[s_, prices.get(s_), r5, vr, 1 if s_ in engine.pos else 0] for s_, r5, vr in S.get("market", [])]
    flow = [o for o in opps if abs(o["biases"]["flow"]) >= 0.4 or abs(o["oi_change_pct"] or 0) >= 1]
    return {
        "status": S["status"], "mode": CFG.mode, "regime": S["regime"], "btc_bias": S.get("btc_bias"),
        "universe": S["universe"], "scan_age": int(now - S["scan_ts"]) if S["scan_ts"] else None,
        "scan_ms": S["scan_ms"], "scan_note": S["scan_note"], "errors": S["errors"],
        "long_candidates": sum(1 for o in opps if o["signal"] == "BUY"),
        "short_candidates": sum(1 for o in opps if o["signal"] == "SELL"),
        "opps": opps[:20], "money_flow": flow[:10], "breakouts": [o for o in opps if o["squeeze"]][:10],
        "positions": pos, "closed": cur[-80:][::-1], "market": mkt,
        "stats": engine.stats(), "equity": round(engine.equity(prices), 2),
        "news": feed.listing(80), "news_status": feed.status, "paused": engine.paused,
        "by_coin": by_coin(prices), "eq_hist": [[int(t), v] for t, v in list(engine.eq_hist)[-240:]],
        "btc_spark": [float(r[4]) for r in (stream.rows.get("BTCUSDT", [])[-60:] if stream else [])],
        "btc_price": prices.get("BTCUSDT"),
        "demo": {"connected": demo.connected, "env": demo.env, "balance": demo.balance, "avail": demo.avail,
                 "sync": demo.sync_info, "mode_on": engine.demo_on},
        "ws": {"connected": stream.connected if stream else 0, "expected": stream.expected if stream else 0,
               "msgs": stream.msgs if stream else 0, "last_err": stream.last_err if stream else "",
               "rest_fallback": S["rest_fallback"]}}


@app.get("/api/state")
def state():
    global LAST_GOOD
    try:
        LAST_GOOD = clean(build_state())
        return JSONResponse(LAST_GOOD)
    except Exception:
        log_err("state")
        return JSONResponse(dict(LAST_GOOD, scan_note="Durum üretilemedi, son iyi veri gösteriliyor",
                                 errors=S["errors"]))


def _guard(req):
    return req.headers.get("x-requested-with") == "terminal"


@app.get("/api/candles")
async def candles(symbol: str, tf: str = "5m"):
    if not stream or symbol not in stream.rows or tf not in ("1m", "5m", "15m", "1h"):
        return JSONResponse({"error": "geçersiz"}, status_code=400)
    rows = await safe(api.klines(symbol, tf, 100))
    if not rows:
        return JSONResponse({"error": "veri yok"}, status_code=502)
    df = rows_to_df(rows)
    from indicators import bollinger, ema
    bu, bm, bl = bollinger(df.c)
    return JSONResponse(clean({"symbol": symbol, "tf": tf, "t": df.t.tolist(), "o": df.o.tolist(), "h": df.h.tolist(),
                               "l": df.l.tolist(), "c": df.c.tolist(), "ema20": ema(df.c, 20).tolist(),
                               "bbu": bu.tolist(), "bbl": bl.tolist()}))


@app.get("/api/settings")
def get_settings():
    return JSONResponse(clean({"schema": settings.schema(), "values": settings.get_values(CFG), "mode": CFG.mode,
                               "paused": engine.paused, "has_pos": len(engine.pos), "auth": auth.enabled,
                               "demo": {"connected": demo.connected, "env": demo.env, "balance": demo.balance,
                                        "avail": demo.avail, "hedge": demo.hedge, "err": demo.err, "log": list(demo.log),
                                        "sync": demo.sync_info, "algo_api": demo.use_algo}}))


@app.post("/api/settings")
async def post_settings(req: Request):
    if not _guard(req):
        return JSONResponse({"ok": False, "errors": ["yetkisiz"]}, status_code=403)
    errs = settings.apply(CFG, (await req.json()).get("values", {}))
    if not errs:
        settings.save(CFG)
    return JSONResponse({"ok": not errs, "errors": errs})


@app.post("/api/control")
async def control(req: Request):
    if not _guard(req):
        return JSONResponse({"ok": False, "msg": "yetkisiz"}, status_code=403)
    a = (await req.json()).get("action")
    if a == "pause":
        engine.paused = True
    elif a == "resume":
        engine.paused = False
    elif a == "close_all":
        engine.paused = True
        n = engine.close_all(stream.price if stream else {}, time.time())
        return JSONResponse({"ok": True, "msg": f"{n} pozisyon için kapatma yapıldı/emri gönderildi, yeni işlemler durduruldu"})
    elif a == "reset":
        if not engine.reset():
            return JSONResponse({"ok": False, "msg": "Açık pozisyon varken sıfırlanamaz"})
    elif a == "sync_balance":
        if engine.pos or not demo.connected or demo.avail is None:
            return JSONResponse({"ok": False, "msg": "Demo bağlı olmalı ve açık pozisyon olmamalı"})
        engine.balance = engine.peak = engine.day_start = float(demo.avail)
    else:
        return JSONResponse({"ok": False, "msg": "bilinmeyen eylem"})
    return JSONResponse({"ok": True, "msg": "Tamam", "paused": engine.paused})


@app.post("/api/close")
async def close_pos(req: Request):
    if not _guard(req):
        return JSONResponse({"ok": False, "msg": "yetkisiz"}, status_code=403)
    sym = str((await req.json()).get("symbol", ""))
    ok, msg = engine.manual_close(sym, stream.price if stream else {}, time.time())
    return JSONResponse({"ok": ok, "msg": msg})


@app.post("/api/sync")
async def sync_now(req: Request):
    if not _guard(req):
        return JSONResponse({"ok": False, "msg": "yetkisiz"}, status_code=403)
    if not (engine.demo_on and demo.connected):
        return JSONResponse({"ok": False, "msg": "Önce DEMO hesabını bağlayıp modu DEMO yapın"})
    try:
        await sync.reconcile(time.time())
        n = await sync.sync_history()
        return JSONResponse({"ok": True, "msg": f"Senkron tamam: {len(demo.pos_cache)} açık pozisyon, {n} yeni geçmiş kaydı"})
    except Exception as ex:
        return JSONResponse({"ok": False, "msg": f"Senkron hatası: {str(ex)[:140]}"})


@app.post("/api/mode")
async def set_mode(req: Request):
    if not _guard(req):
        return JSONResponse({"ok": False, "msg": "yetkisiz"}, status_code=403)
    m = (await req.json()).get("mode")
    if m not in ("PAPER", "DEMO"):
        return JSONResponse({"ok": False, "msg": "geçersiz mod"})
    if m == "DEMO" and not demo.connected:
        return JSONResponse({"ok": False, "msg": "Önce demo hesabını bağlayın"})
    if engine.pos and m != CFG.mode:
        return JSONResponse({"ok": False, "msg": "Mod değiştirmeden önce açık pozisyonları kapatın"})
    CFG.mode = m
    return JSONResponse({"ok": True, "mode": m})


@app.post("/api/demo/connect")
async def demo_connect(req: Request):
    if not _guard(req):
        return JSONResponse({"ok": False, "msg": "yetkisiz"}, status_code=403)
    b = await req.json()
    try:
        await demo.connect(b.get("key", ""), b.get("secret", ""), b.get("env", "demo"))
        return JSONResponse({"ok": True, "balance": demo.balance})
    except Exception as e:
        demo.forget()
        demo.err = str(e)[:200]
        return JSONResponse({"ok": False, "msg": demo.err})


@app.post("/api/demo/disconnect")
async def demo_disconnect(req: Request):
    if not _guard(req):
        return JSONResponse({"ok": False, "msg": "yetkisiz"}, status_code=403)
    n = engine.drop_exchange_positions() if engine.demo_on else 0
    demo.forget()
    CFG.mode = "PAPER"
    return JSONResponse({"ok": True, "msg": f"{n} pozisyon Binance'te (SL/TP emirleriyle) kalır" if n else "Bağlantı kesildi"})


def _startup_check():
    """Ağa açılıyorsa şifre olmadan başlamayı reddeder."""
    if not is_loopback(HOST) and not auth.enabled:
        sys.exit("HATA: Ağa açık modda (TERMINAL_HOST=%s) şifre zorunlu. TERMINAL_PIN ortam değişkenini en az %d "
                 "karakterlik bir şifreyle ayarlayın (baslat_telefon.bat bunu sorar)." % (HOST, MIN_LEN))
    if auth.enabled and len(PIN) < MIN_LEN:
        sys.exit(f"HATA: TERMINAL_PIN en az {MIN_LEN} karakter olmalı.")


if __name__ == "__main__":
    _startup_check()
    print(f"\n  CRYPTO AI TERMINAL  ->  bu bilgisayardan: http://localhost:{PORT}")
    if not is_loopback(HOST):
        ip = local_ip()
        if ip:
            print(f"  Telefondan (aynı Wi-Fi):  http://{ip}:{PORT}")
        print("  Şifre korumalı. PC açık ve internete bağlı kalmalı.\n")
    uvicorn.run(app, host=HOST, port=PORT, log_level="warning", proxy_headers=TRUST_PROXY,
                forwarded_allow_ips="*" if TRUST_PROXY else "127.0.0.1")
