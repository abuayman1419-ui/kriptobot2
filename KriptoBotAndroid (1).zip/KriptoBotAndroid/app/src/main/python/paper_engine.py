"""İşlem motoru + risk yöneticisi.
PAPER modu: tamamen sanal, borsa çağrısı yok.
DEMO modu: pozisyonların gerçek durumu Binance'tedir (SL/TP emirleri de orada); motor yalnızca karar verir ve
borsadaki durumu `exchange_sync` ile yansıtır."""
import json
import os
import time
from collections import deque
from datetime import datetime, timezone

EXT_BLOCK_SECONDS = 1800      # Binance'te elle kapatılan coine bu süre yeniden girilmez


class PaperEngine:
    def __init__(self, cfg):
        self.cfg = cfg
        self.balance = cfg.start_balance
        self.base = cfg.start_balance          # grafik/istatistik başlangıç bakiyesi (DEMO'da borsa bakiyesi)
        self.pos = {}
        self.closed = []
        self.consec_losses = 0
        self.cooldown_until = 0.0
        self.peak = cfg.start_balance
        self.max_dd = 0.0
        self.day = self._today()
        self.day_start = cfg.start_balance
        self.halted = None
        self.safe_mode = False
        self.paused = False
        self.demo_on = False
        self.mode = "PAPER"
        self.need_sync = False                 # DEMO: ilk Binance senkronu bitmeden yeni işlem açılmaz
        self.sync_fail = 0
        self.blocked = {}                      # sembol -> bu zamana kadar yeni işlem yok
        self.seen = set()                      # kayda geçmiş Binance işlem (fill) kimlikleri
        self.queue = []
        self.eq_hist = deque(maxlen=720)
        os.makedirs(cfg.log_dir, exist_ok=True)
        self.log_path = os.path.join(cfg.log_dir, "paper_trades.jsonl")

    @staticmethod
    def _today():
        return datetime.now(timezone.utc).strftime("%Y-%m-%d")

    # ---------- değerleme ----------
    def unrealized(self, prices):
        t = 0.0
        for s, p in self.pos.items():
            px = prices.get(s) or p.get("mark") or p["entry"]
            t += (px - p["entry"]) * p["qty_open"] * p["dir"]
        return t

    def equity(self, prices):
        return self.balance + self.unrealized(prices)

    def cur_closed(self):
        return [r for r in self.closed if r.get("mode", "PAPER") == self.mode]

    # ---------- risk kapıları ----------
    def can_open(self, symbol, now):
        c = self.cfg
        if self.day != self._today():
            self.day, self.day_start, self.halted = self._today(), self.balance, None
        if self.paused:
            return False, "Alım-satım elle durduruldu"
        if self.safe_mode:
            return False, "Veri akışı güvenli modda"
        if self.demo_on and self.need_sync:
            return False, "Binance senkronu bekleniyor"
        if self.demo_on and self.sync_fail >= 3:
            return False, "Binance ile senkron kurulamıyor"
        if self.halted:
            return False, self.halted
        if symbol in self.pos:
            return False, "Aynı coinde açık pozisyon var"
        if self.blocked.get(symbol, 0) > now:
            return False, "Binance'te elle kapatılan coin (bekleme)"
        if len(self.pos) >= c.max_positions:
            return False, "Maksimum açık pozisyon"
        if now < self.cooldown_until:
            return False, "Üst üste zarar sonrası bekleme"
        if self.balance - self.day_start <= -c.daily_loss_pct * self.day_start:
            self.halted = "Günlük zarar limiti doldu"
            return False, self.halted
        return True, ""

    # ---------- işlem açma ----------
    def open(self, opp, price, now):
        c = self.cfg
        ok, why = self.can_open(opp["symbol"], now)
        if not ok:
            return False, why
        if abs(price - opp["price"]) > c.max_slippage_atr * opp["atr"]:
            return False, "Fiyat sinyalden fazla kaçtı"
        d = 1 if opp["side"] == "LONG" else -1
        r = abs(opp["price"] - opp["sl"])            # 1R (fiyat cinsinden)
        sl = price - d * r
        tps = [price + d * k * r for k in c.tp_r]
        risk_amt = self.balance * c.risk_pct
        qty = risk_amt / r
        max_notional = self.balance * c.margin_pct * c.leverage
        qty = min(qty, max_notional / price)
        if qty * price < 5:
            return False, "Pozisyon çok küçük"
        fee = 0.0 if self.demo_on else qty * price * c.taker_fee
        self.balance -= fee
        self.pos[opp["symbol"]] = {
            "symbol": opp["symbol"], "side": opp["side"], "dir": d, "entry": price, "qty": qty,
            "qty_open": qty, "sl": sl, "sl0": sl, "tps": tps, "tp_hit": 0, "leverage": c.leverage,
            "margin": qty * price / c.leverage, "opened": now, "fees": fee, "realized": 0.0,
            "score": opp["score"], "reason": opp["note"], "hist": deque(maxlen=40),
            "rdist": r, "pending": self.demo_on, "external": False, "tp_plan": [], "closing": False,
            "close_reason": None, "mark": price}
        if self.demo_on:
            self.queue.append({"kind": "open", "sym": opp["symbol"], "side": opp["side"], "qty": qty, "price": price})
        return True, ""

    def confirm_open(self, sym, fill_px, fill_qty):
        """DEMO: giriş emri doldu; gerçek dolum fiyat/miktarına göre SL ve TP'leri yeniden hesapla."""
        p = self.pos.get(sym)
        if not p:
            return None
        d, r = p["dir"], p["rdist"]
        p["entry"], p["qty"], p["qty_open"] = fill_px, fill_qty, fill_qty
        p["sl"] = p["sl0"] = fill_px - d * r
        p["tps"] = [fill_px + d * k * r for k in self.cfg.tp_r]
        p["margin"] = fill_qty * fill_px / p["leverage"]
        p["mark"] = fill_px
        return p

    # ---------- fiyat takibi ----------
    def mark(self, prices, now):
        if self.demo_on:
            return self._mark_demo(prices, now)
        c = self.cfg
        for s in list(self.pos):
            p = self.pos[s]
            px = prices.get(s)
            if px is None:
                continue
            d = p["dir"]
            p["hist"].append((now, px))
            old = next((x for t, x in p["hist"] if now - t <= 60), None)
            if old and (px - old) / old * 100 * d <= -c.panic_move_pct:
                self._close(p, p["qty_open"], px, "Ani volatilite koruması", now)
                continue
            if (px - p["sl"]) * d <= 0:
                self._close(p, p["qty_open"], px, "Stop Loss" if p["tp_hit"] == 0 else "Stop (kâr korumalı)", now)
                continue
            while p["tp_hit"] < len(p["tps"]) and (px - p["tps"][p["tp_hit"]]) * d >= 0:
                i = p["tp_hit"]
                last_tp = i == len(p["tps"]) - 1
                q = p["qty_open"] if last_tp else min(p["qty_open"], p["qty"] * c.tp_split[i])
                p["tp_hit"] += 1
                if i == 0:
                    p["sl"] = p["entry"]                # TP1 sonrası başa baş
                elif i == 1:
                    p["sl"] = p["tps"][0]               # TP2 sonrası kâr kilidi
                self._close(p, q, p["tps"][i], f"TP{i + 1}", now)
                if s not in self.pos:
                    break
            if s in self.pos and now - p["opened"] > c.max_hold_minutes * 60:
                self._close(p, p["qty_open"], px, "Zaman aşımı", now)

    def _mark_demo(self, prices, now):
        """DEMO: SL/TP'yi Binance yönetir. Burada yalnızca (bot çalışıyorsa) panik ve zaman aşımı kapatması istenir."""
        c = self.cfg
        for s, p in list(self.pos.items()):
            px = prices.get(s)
            if px is None or p.get("pending"):
                continue
            p["mark"] = px
            p["hist"].append((now, px))
            if self.paused or p["external"] or p["closing"]:
                continue                                  # durdurulmuşsa / dışarıdan gelen pozisyonsa bota ait müdahale yok
            d = p["dir"]
            old = next((x for t, x in p["hist"] if now - t <= 60), None)
            reason = None
            if old and (px - old) / old * 100 * d <= -c.panic_move_pct:
                reason = "Ani volatilite koruması"
            elif now - p["opened"] > c.max_hold_minutes * 60:
                reason = "Zaman aşımı"
            if reason:
                p["closing"] = True
                self.queue.append({"kind": "manual_close", "sym": s, "reason": reason})

    def _close(self, p, qty, price, reason, now):
        """PAPER: sanal kapanış."""
        c = self.cfg
        pnl = (price - p["entry"]) * qty * p["dir"]
        fee = price * qty * c.taker_fee
        self.balance += pnl - fee
        p["fees"] += fee
        p["qty_open"] -= qty
        full = p["qty_open"] <= 1e-12
        self._record(p, qty, price, pnl - fee, reason, now, full)

    def _record(self, p, qty, price, pnl_net, reason, now, full, src=None):
        c = self.cfg
        p["realized"] += pnl_net
        rec = {"time": datetime.fromtimestamp(now, timezone.utc).isoformat(timespec="seconds"),
               "symbol": p["symbol"], "side": p["side"], "entry": p["entry"], "exit": price,
               "qty": qty, "pnl": round(pnl_net, 4), "reason": reason,
               "final": full, "duration_s": int(now - p["opened"]), "leverage": p["leverage"],
               "score": p["score"], "open_reason": p["reason"],
               "trade_total": round(p["realized"], 4) if full else None, "mode": self.mode}
        if src:
            rec["src"] = src
        self.closed.append(rec)
        try:
            with open(self.log_path, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
        except OSError:
            pass
        self.peak = max(self.peak, self.balance)
        self.max_dd = max(self.max_dd, (self.peak - self.balance) / self.peak) if self.peak else 0
        if full:
            total = p["realized"]
            self.consec_losses = self.consec_losses + 1 if total < 0 else 0
            if self.consec_losses >= c.max_consec_losses:
                self.cooldown_until = now + c.cooldown_minutes * 60
                self.consec_losses = 0
            self.pos.pop(p["symbol"], None)
            p["total"] = total

    # ---------- DEMO: Binance'ten gelen olaylar ----------
    def record_exchange(self, p, qty, price, pnl_net, reason, now, full, trade_ids):
        """Binance'te gerçekleşen bir kapanış parçasını kaydeder (pozisyon p motorda açıkken)."""
        self.seen.update(trade_ids)
        p["qty_open"] = max(0.0, p["qty_open"] - qty)
        self._record(p, qty, price, pnl_net, reason, now, full, src="binance")

    def import_history(self, rows):
        """Geçmiş Binance kapanışlarını (motorda pozisyonu olmayan) kayıt listesine ekler."""
        n = 0
        for r in rows:
            ids = set(r["ids"])
            if ids & self.seen:
                continue
            self.seen.update(ids)
            self.closed.append({"time": datetime.fromtimestamp(r["time"], timezone.utc).isoformat(timespec="seconds"),
                                "symbol": r["symbol"], "side": r["side"], "entry": None, "exit": r["price"], "qty": r["qty"],
                                "pnl": round(r["pnl"], 4), "reason": "Binance geçmişi", "final": True, "duration_s": 0,
                                "leverage": None, "score": None, "open_reason": "", "trade_total": round(r["pnl"], 4),
                                "mode": "DEMO", "src": "binance"})
            n += 1
        self.closed.sort(key=lambda x: x["time"])
        return n

    def adopt(self, e, sl, tps, now):
        """Binance'te olup motorda olmayan pozisyonu motora alır (dışarıdan açılmış / uygulama yeniden başlamış)."""
        d = 1 if e["side"] == "LONG" else -1
        lev = e.get("lev") or self.cfg.leverage
        self.pos[e["symbol"]] = {
            "symbol": e["symbol"], "side": e["side"], "dir": d, "entry": e["entry"], "qty": e["qty"], "qty_open": e["qty"],
            "sl": sl, "sl0": sl, "tps": tps, "tp_hit": 0, "leverage": lev,
            "margin": e["qty"] * e["entry"] / lev, "opened": e.get("t") or time.time(), "fees": 0.0, "realized": 0.0,
            "score": None, "reason": "Binance'te açık pozisyon", "hist": deque(maxlen=40), "rdist": 0,
            "pending": False, "external": True, "tp_plan": [], "closing": False, "close_reason": None,
            "mark": e.get("mark") or e["entry"]}
        return self.pos[e["symbol"]]

    def block(self, sym, now):
        self.blocked[sym] = now + EXT_BLOCK_SECONDS

    def drop_exchange_positions(self):
        """Binance bağlantısı kesilirken: pozisyonlar Binance'te kalır, motordan çıkarılır."""
        n = len(self.pos)
        self.pos.clear()
        self.queue.clear()
        return n

    # ---------- elle kontrol ----------
    def manual_close(self, sym, prices, now):
        p = self.pos.get(sym)
        if not p:
            return False, "Açık pozisyon bulunamadı"
        if self.demo_on:
            if p.get("pending"):
                return False, "Pozisyon açılıyor, birkaç saniye sonra tekrar deneyin"
            p["closing"] = True
            self.queue.append({"kind": "manual_close", "sym": sym, "reason": "Elle kapatıldı"})
            return True, f"{sym} kapatma emri Binance'e gönderiliyor"
        self._close(p, p["qty_open"], prices.get(sym, p["entry"]), "Elle kapatıldı", now)
        return True, f"{sym} kapatıldı"

    def close_all(self, prices, now, reason="Elle kapatıldı"):
        n = 0
        for s in list(self.pos):
            p = self.pos[s]
            if self.demo_on:
                if p.get("pending"):
                    continue
                p["closing"] = True
                self.queue.append({"kind": "manual_close", "sym": s, "reason": reason})
            else:
                self._close(p, p["qty_open"], prices.get(s, p["entry"]), reason, now)
            n += 1
        return n

    def abort(self, sym):
        """Demo giriş emri reddedilirse / iptal edilirse sanal pozisyonu geri al."""
        p = self.pos.pop(sym, None)
        if p:
            self.balance += p["fees"]

    def reset(self):
        if self.pos or self.demo_on:
            return False
        self.balance = self.peak = self.base = self.cfg.start_balance
        self.day_start, self.max_dd, self.halted = self.balance, 0.0, None
        self.closed = [r for r in self.closed if r.get("mode", "PAPER") != "PAPER"]
        self.consec_losses, self.cooldown_until = 0, 0.0
        return True

    # ---------- istatistik ----------
    def stats(self):
        cl = self.cur_closed()
        pnls = [r["pnl"] for r in cl]
        wins = [x for x in pnls if x > 0]
        losses = [x for x in pnls if x <= 0]
        gl = -sum(losses)
        longs = [r["pnl"] for r in cl if r["side"] == "LONG"]
        shorts = [r["pnl"] for r in cl if r["side"] == "SHORT"]
        sr = lambda a: round(100 * sum(1 for x in a if x > 0) / len(a), 1) if a else None
        return {
            "start_balance": round(self.base, 2), "balance": round(self.balance, 2),
            "net_pnl": round(self.balance - self.base, 2),
            "fills": len(pnls), "win_rate": sr(pnls),
            "profit_factor": round(sum(wins) / gl, 2) if gl > 0 else None,
            "avg_win": round(sum(wins) / len(wins), 3) if wins else None,
            "avg_loss": round(-gl / len(losses), 3) if losses else None,
            "max_drawdown_pct": round(self.max_dd * 100, 2),
            "long_success": sr(longs), "short_success": sr(shorts),
            "halted": self.halted, "safe_mode": self.safe_mode, "paused": self.paused,
        }
