"""Tüm ayarlar burada. LIVE_TRADING bilinçli olarak yoktur: bu sürümde gerçek emir kodu bulunmaz."""
from dataclasses import dataclass, field


@dataclass
class Config:
    mode: str = "PAPER"
    # --- Evren ---
    min_qv24: float = 0               # evren: 24s hacim alt sınırı (0 = Binance'teki TÜM USDT perpetual coinler izlenir)
    min_trade_qv24: float = 5_000_000  # işlem açmak için 24s hacim alt sınırı (ince coinlerde işlem açılmaz)
    max_symbols: int = 1000           # akışa alınacak en fazla sembol sayısı
    warmup_candles: int = 100
    stream_chunk: int = 100           # bağlantı başına stream sayısı
    # --- Tarama ---
    scan_seconds: int = 60
    deep_n: int = 20                  # derin analize alınacak aday sayısı
    stale_seconds: int = 20           # bundan eski veriyle işlem açılmaz
    # --- Puanlama (toplam 100) ---
    weights: dict = field(default_factory=lambda: {
        "technical": 25, "flow": 20, "trend": 15, "orderbook": 10,
        "news": 10, "btc": 10, "oi_funding": 10})
    entry_threshold: float = 80
    opposite_max: float = 50
    max_spread_pct: float = 0.10
    max_chase_atr: float = 2.5
    min_sl_pct: float = 0.30
    max_sl_pct: float = 5.0
    sl_atr_mult: float = 1.5
    # --- Paper trading ---
    start_balance: float = 200.0
    leverage: int = 8
    max_positions: int = 2
    margin_pct: float = 0.45
    risk_pct: float = 0.02
    taker_fee: float = 0.0005
    tp_split: tuple = (0.5, 0.25, 0.25)
    tp_r: tuple = (1.0, 2.0, 3.0)
    max_hold_minutes: int = 180
    daily_loss_pct: float = 0.10
    max_consec_losses: int = 3
    cooldown_minutes: int = 30
    panic_move_pct: float = 1.5
    max_slippage_atr: float = 0.5
    log_dir: str = "logs"


CFG = Config()
