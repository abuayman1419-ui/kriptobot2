"""DEMO modu: motor <-> Binance senkronu ve emir yürütme.

İlkeler
- Gerçeğin kaynağı Binance'tir. Her ~4 sn pozisyonlar ve koşullu emirler okunur, motor buna göre düzeltilir.
- Giriş emri dolunca SL (STOP_MARKET, closePosition) ve TP1/TP2/TP3 (TAKE_PROFIT_MARKET) hemen Binance'e yazılır.
  SL konamazsa pozisyon anında piyasa emriyle kapatılır (korumasız pozisyon bırakılmaz).
- Pozisyon Binance'te (elle/SL/TP ile) kapanırsa motor bunu görür, kaydeder ve artık işlem yapmaz; yeniden açmaz.
- Bot durdurulduğunda koruma emirleri Binance'te kalır ve bot onlara DOKUNMAZ (kontrol Binance'tedir)."""
import time

from demo_exec import PREFIX, fmt

DEFAULT_FLT = {"step": 0.001, "minq": 0.001, "notional": 5, "tick": 0}


class ExchangeSync:
    def __init__(self, engine, demo, filters, cfg):
        self.e, self.d, self.filters, self.cfg = engine, demo, filters, cfg
        self.last_balance = 0.0

    def flt(self, sym):
        return self.filters.get(sym, DEFAULT_FLT)

    # ======================= emir kuyruğu =======================
    async def process_queue(self):
        e, d = self.e, self.d
        while e.queue:
            o = e.queue.pop(0)
            async with d.lock:
                try:
                    if o["kind"] == "open":
                        await self._open(o)
                    elif o["kind"] == "manual_close":
                        await self._manual_close(o)
                    elif o["kind"] == "move_sl":
                        await self._move_sl(o)
                except Exception as ex:
                    d.note(f"HATA {o['kind']} {o.get('sym')}: {str(ex)[:140]}")
                    if o["kind"] == "open":
                        e.abort(o["sym"])
                    elif o["kind"] == "manual_close" and o["sym"] in e.pos:
                        e.pos[o["sym"]]["closing"] = False

    async def _open(self, o):
        e, d = self.e, self.d
        sym = o["sym"]
        p = e.pos.get(sym)
        if not p:
            return
        if e.paused or not e.demo_on:
            e.abort(sym)
            return
        if sym in d.pos_cache:
            d.note(f"{sym}: Binance'te zaten pozisyon var, yeni giriş yapılmadı")
            e.abort(sym)
            return
        flt = self.flt(sym)
        r = await d.place(sym, o["side"], o["qty"], False, flt, p["leverage"], o["price"])
        px = float(r.get("avgPrice") or 0) or o["price"]
        q = float(r.get("executedQty") or 0)
        if q <= 0:
            q = float(d.fit(o["qty"], flt))          # RESULT yanıtında miktar yoksa istenen miktar
        p = e.confirm_open(sym, px, q)
        if p is None:
            return
        try:
            await self._protect(p)
        except Exception as ex:
            # Korumasız pozisyon bırakma: hemen kapat
            d.note(f"{sym}: SL konamadı ({str(ex)[:100]}), pozisyon kapatılıyor")
            try:
                await d.close_market(sym, p["side"], fmt(d.fit(q, flt)))
                p["close_reason"] = "SL konamadığı için kapatıldı"
            except Exception as ex2:
                d.note(f"{sym}: ACİL KAPATMA HATASI {str(ex2)[:100]}")
        p["pending"] = False

    async def _protect(self, p):
        """SL + TP emirlerini Binance'e yazar. SL hata verirse istisna fırlatır."""
        d, e = self.d, self.e
        sym, side, flt = p["symbol"], p["side"], self.flt(p["symbol"])
        await d.conditional(sym, side, "STOP_MARKET", p["sl"], flt, close=True, role="sl", working="MARK_PRICE")
        qty = p["qty"]
        plan, used = [], 0.0
        for i in (0, 1):
            q = float(d.fit(qty * e.cfg.tp_split[i], flt))
            if q <= 0 or q < flt.get("minq", 0) or used + q >= qty - float(flt.get("step") or 0):
                continue
            try:
                await d.conditional(sym, side, "TAKE_PROFIT_MARKET", p["tps"][i], flt, qty=q, role=f"tp{i + 1}")
                plan.append((i, q))
                used += q
            except Exception as ex:
                d.note(f"{sym} TP{i + 1} konamadı: {str(ex)[:100]}")
        try:
            await d.conditional(sym, side, "TAKE_PROFIT_MARKET", p["tps"][2], flt, close=True, role="tp3")
        except Exception as ex:
            d.note(f"{sym} TP3 konamadı: {str(ex)[:100]}")
        p["tp_plan"] = plan

    async def _manual_close(self, o):
        e, d = self.e, self.d
        sym = o["sym"]
        p = e.pos.get(sym)
        if p:
            p["close_reason"] = o.get("reason") or "Elle kapatıldı"
        ex = (await d.positions()).get(sym)
        if ex:
            await d.close_market(sym, ex["side"], ex["qty_str"])      # önce kapat; hata olursa koruma emirleri yerinde kalır
        for a in await d.open_algo():
            if a["sym"] == sym:
                try:
                    await d.cancel_algo(a)
                except Exception:
                    pass

    async def _move_sl(self, o):
        e, d = self.e, self.d
        sym, new = o["sym"], o["price"]
        p = e.pos.get(sym)
        if not p or p["external"] or sym not in d.pos_cache:
            return
        flt = self.flt(sym)
        old = [a for a in await d.open_algo()
               if a["sym"] == sym and a["type"].startswith("STOP") and a["close"] and a["cid"].startswith(PREFIX)]
        old_px = old[0]["trig"] if old else p["sl"]
        for a in old:
            await d.cancel_algo(a)
        for px in (new, old_px):
            try:
                await d.conditional(sym, p["side"], "STOP_MARKET", px, flt, close=True, role="sl", working="MARK_PRICE")
                p["sl"] = px
                if px == new:
                    d.note(f"{sym}: SL {fmt(new)} seviyesine taşındı")
                return
            except Exception as ex:
                d.note(f"{sym}: SL {fmt(px)} konamadı: {str(ex)[:90]}")
        ex = d.pos_cache.get(sym)
        if ex:
            await d.close_market(sym, ex["side"], ex["qty_str"])      # hiçbir SL konamadı: korumasız bırakma
            p["close_reason"] = "SL konamadığı için kapatıldı"

    # ======================= senkron =======================
    async def reconcile(self, now):
        """Binance'teki gerçek durumu motora yansıtır. Hata verirse istisna fırlatır (çağıran sayar)."""
        e, d = self.e, self.d
        async with d.lock:
            ex = await d.positions()
            algos = await d.open_algo()
            d.pos_cache, d.algo_cache = ex, algos
            pend = {s for s, p in e.pos.items() if p.get("pending")}
            # 1) motordaki pozisyonlar
            for sym, p in list(e.pos.items()):
                if p.get("pending"):
                    continue
                x = ex.get(sym)
                if x is None:
                    await self._gone(sym, p, now)
                    continue
                p["mark"] = x["mark"] or p["mark"]
                if x["qty"] < p["qty_open"] - max(1e-9, float(self.flt(sym).get("step") or 0) * 0.5):
                    await self._reduced(sym, p, x, now)
                elif p["external"]:
                    p.update(entry=x["entry"], qty=max(p["qty"], x["qty"]), qty_open=x["qty"])
                    self._refresh_levels(p, algos)
                else:
                    p["qty_open"] = x["qty"]
            # 2) Binance'te olup motorda olmayanlar -> motora al
            for sym, x in ex.items():
                if sym not in e.pos:
                    sl, tps = self._levels(x, algos)
                    e.adopt(x, sl, tps, now)
                    d.note(f"{sym}: Binance'teki {x['side']} pozisyon motora alındı")
            # 3) pozisyonu kalmamış coinlerde bota ait artık emirleri temizle
            alive = set(ex) | pend
            for a in algos:
                if a["cid"].startswith(PREFIX) and a["sym"] not in alive:
                    try:
                        await d.cancel_algo(a)
                    except Exception:
                        pass
            # 4) bot yönetimindeki pozisyonda SL emri yoksa (silinmiş/hatalı) yeniden koy; durdurulmuşsa dokunma
            if not e.paused:
                for sym, p in list(e.pos.items()):
                    if p.get("pending") or p["external"] or sym not in ex:
                        continue
                    has = any(a["sym"] == sym and a["type"].startswith("STOP") for a in algos)
                    if not has and now - p.get("sl_retry", 0) > 30:
                        p["sl_retry"] = now
                        try:
                            await d.conditional(sym, p["side"], "STOP_MARKET", p["sl"], self.flt(sym), close=True,
                                                role="sl", working="MARK_PRICE")
                        except Exception as ex2:
                            d.note(f"{sym}: SL yeniden konamadı: {str(ex2)[:90]}")
            # 5) bakiye
            if e.demo_on and now - self.last_balance > 10:
                self.last_balance = now
                await d.refresh_balance()
                if d.balance is not None and not pend:
                    e.balance = d.balance
                    e.peak = max(e.peak, e.balance)
            e.need_sync, e.sync_fail = False, 0
            d.sync_info.update(ts=now, pos=len(ex), algo=len(algos), err="")

    # ---------- yardımcılar ----------
    @staticmethod
    def _levels(x, algos):
        """Binance'teki koşullu emirlerden SL ve TP seviyelerini çıkarır."""
        sym, d = x["symbol"], 1 if x["side"] == "LONG" else -1
        sl, tps = None, []
        for a in algos:
            if a["sym"] != sym:
                continue
            if a["type"].startswith("STOP"):
                if sl is None or (a["trig"] - sl) * d > 0:      # en yakın (en korumacı değil) -> en yüksek eşik
                    sl = a["trig"]
            elif a["type"].startswith("TAKE_PROFIT"):
                tps.append(a["trig"])
        tps = sorted(set(tps), key=lambda v: (v - x["entry"]) * d)
        return sl, tps

    def _refresh_levels(self, p, algos):
        sl, tps = self._levels({"symbol": p["symbol"], "side": p["side"], "entry": p["entry"]}, algos)
        p["sl"], p["tps"] = sl, tps

    def _pieces(self, p, fills, only_closing=True):
        """Henüz kaydedilmemiş kapanış dolumlarını emir bazında gruplar."""
        e = self.e
        closing_side = "SELL" if p["dir"] == 1 else "BUY"
        t0 = p["opened"] * 1000 - 15000
        groups = {}
        for t in fills:
            tid = int(t["id"])
            if tid in e.seen or t["side"] != closing_side or float(t["time"]) < t0:
                continue
            ps = t.get("positionSide", "BOTH")
            if ps not in ("BOTH", p["side"]):
                continue
            g = groups.setdefault(t["orderId"], {"qty": 0.0, "notional": 0.0, "pnl": 0.0, "time": 0, "ids": []})
            q, pr = float(t["qty"]), float(t["price"])
            g["qty"] += q
            g["notional"] += q * pr
            g["pnl"] += float(t.get("realizedPnl") or 0) - float(t.get("commission") or 0)
            g["time"] = max(g["time"], int(t["time"]))
            g["ids"].append(tid)
        out = []
        for g in sorted(groups.values(), key=lambda g: g["time"]):
            g["price"] = g["notional"] / g["qty"] if g["qty"] else 0
            out.append(g)
        return out

    @staticmethod
    def _reason(p, px):
        near = lambda a, b, tol: a and b and abs(a - b) / b <= tol
        for i, tp in enumerate(p["tps"]):
            if near(px, tp, 0.0025):
                return f"TP{i + 1}"
        if near(px, p["entry"], 0.0015) and p["tp_hit"] > 0:
            return "Stop (kâr korumalı)"
        if near(px, p["sl"], 0.003) or near(px, p["sl0"], 0.003):
            return "Stop Loss" if p["tp_hit"] == 0 else "Stop (kâr korumalı)"
        return p.get("close_reason") or "Binance'te elle kapatıldı"

    async def _gone(self, sym, p, now):
        """Pozisyon Binance'te tamamen kapanmış."""
        e, d = self.e, self.d
        try:
            fills = await d.trades(sym, p["opened"] * 1000 - 15000)
        except Exception:
            fills = []
        pieces = self._pieces(p, fills)
        manual = False
        if not pieces:
            px = p.get("mark") or p["entry"]
            pnl = (px - p["entry"]) * p["qty_open"] * p["dir"]
            e.record_exchange(p, p["qty_open"], px, pnl, p.get("close_reason") or "Binance'te kapandı (fiyat tahmini)", now, True, [])
            manual = not p.get("close_reason")
        else:
            for i, g in enumerate(pieces):
                last = i == len(pieces) - 1
                reason = self._reason(p, g["price"])
                manual = last and reason == "Binance'te elle kapatıldı"
                e.record_exchange(p, g["qty"], g["price"], g["pnl"], reason, g["time"] / 1000.0, last, g["ids"])
            if e.pos.get(sym) is p:          # parçalar toplamı eksik kalsa da pozisyonu kapat
                e.pos.pop(sym, None)
        if manual and not p["external"]:
            e.block(sym, now)
        d.note(f"{sym}: pozisyon Binance'te kapandı")

    async def _reduced(self, sym, p, x, now):
        """Pozisyon Binance'te kısmen azalmış (TP1/TP2 doldu ya da elle azaltıldı)."""
        e, d = self.e, self.d
        try:
            fills = await d.trades(sym, p["opened"] * 1000 - 15000)
        except Exception:
            fills = []
        for g in self._pieces(p, fills):
            e.record_exchange(p, g["qty"], g["price"], g["pnl"], self._reason(p, g["price"]), g["time"] / 1000.0, False, g["ids"])
        p["qty_open"] = x["qty"]
        if p["external"]:
            return
        filled = p["qty"] - x["qty"]
        cum, hit = 0.0, 0
        for _, q in p["tp_plan"]:
            cum += q
            if filled >= cum * 0.999:
                hit += 1
        if hit > p["tp_hit"]:
            old = p["tp_hit"]
            p["tp_hit"] = hit
            if not e.paused:
                lvl = p["tp_plan"][hit - 1][0]
                new_sl = p["entry"] if lvl == 0 else p["tps"][lvl - 1]
                e.queue.append({"kind": "move_sl", "sym": sym, "price": new_sl})
            d.note(f"{sym}: TP{p['tp_plan'][hit - 1][0] + 1} doldu")

    # ======================= geçmiş =======================
    async def sync_history(self, days=7, max_symbols=25):
        """Binance'teki son günlerin kapanış işlemlerini çekip geçmişe ekler."""
        e, d = self.e, self.d
        start = (time.time() - days * 86400) * 1000
        n = 0
        async with d.lock:
            for sym in (await d.income_symbols(days))[:max_symbols]:
                rows = {}
                for t in await d.trades(sym, start):
                    if float(t.get("realizedPnl") or 0) == 0 or int(t["id"]) in e.seen:
                        continue
                    ps = t.get("positionSide", "BOTH")
                    side = ps if ps in ("LONG", "SHORT") else ("SHORT" if t["side"] == "BUY" else "LONG")
                    g = rows.setdefault(t["orderId"], {"symbol": sym, "side": side, "qty": 0.0, "notional": 0.0, "pnl": 0.0,
                                                       "time": 0, "ids": []})
                    q = float(t["qty"])
                    g["qty"] += q
                    g["notional"] += q * float(t["price"])
                    g["pnl"] += float(t["realizedPnl"]) - float(t.get("commission") or 0)
                    g["time"] = max(g["time"], int(t["time"]))
                    g["ids"].append(int(t["id"]))
                batch = []
                for g in rows.values():
                    g["price"] = g["notional"] / g["qty"] if g["qty"] else 0
                    g["time"] /= 1000.0
                    batch.append(g)
                n += e.import_history(batch)
        d.sync_info["hist"] = n
        d.note(f"Binance geçmişi: {n} kapanış işlemi eklendi")
        return n
