package com.kriptobot.terminal

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.TextView
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var status: TextView
    private val ui = Handler(Looper.getMainLooper())
    private var begun = false
    private val base = "http://127.0.0.1:8000"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this)
        root.setBackgroundColor(0xFF0B0F17.toInt())
        web = WebView(this)
        status = TextView(this).apply {
            setTextColor(0xFFD8E0EE.toInt())
            textSize = 15f
            setPadding(48, 48, 48, 48)
            gravity = Gravity.CENTER
            setTextIsSelectable(true)
            text = "Bot başlatılıyor…\nİlk açılışta 20-60 sn sürebilir."
        }
        val mp = ViewGroup.LayoutParams.MATCH_PARENT
        root.addView(web, FrameLayout.LayoutParams(mp, mp))
        root.addView(status, FrameLayout.LayoutParams(mp, mp))
        setContentView(root)
        setupWebView()

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        } else {
            begin()
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        begin()
    }

    private fun begin() {
        if (begun) return
        begun = true
        startForegroundService(Intent(this, BotService::class.java))
        askBatteryExemption()
        waitForServerThenLoad()
    }

    /** Android'in botu arka planda kapatmaması için "pil kısıtlaması yok" izni (sistem penceresi açılır). */
    private fun askBatteryExemption() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(packageName)) return
        AlertDialog.Builder(this)
            .setTitle("Arka planda çalışma izni")
            .setMessage("Bot kapalı ekranda da çalışabilsin diye Android'in pil kısıtlamasından muaf tutulması gerekir. Sıradaki pencerede \"İzin ver\"e dokunun.")
            .setPositiveButton("Devam") { _, _ ->
                try {
                    startActivity(
                        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                    )
                } catch (_: Exception) {
                }
            }
            .setNegativeButton("Şimdi değil", null)
            .show()
    }

    private fun ready(): Boolean = try {
        val c = URL("$base/login").openConnection() as HttpURLConnection
        c.connectTimeout = 800
        c.readTimeout = 2000
        val ok = c.responseCode in 200..399
        c.disconnect()
        ok
    } catch (e: Exception) {
        false
    }

    private fun login() {
        try {
            val c = URL("$base/login").openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = 3000
            c.readTimeout = 5000
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("X-Requested-With", "terminal")
            c.outputStream.use { it.write("""{"pin":"${Prefs.pin(this)}"}""".toByteArray()) }
            if (c.responseCode == 200) {
                val cm = CookieManager.getInstance()
                (c.headerFields["Set-Cookie"] ?: c.headerFields["set-cookie"])?.forEach { cm.setCookie(base, it) }
                cm.flush()
            }
            c.disconnect()
        } catch (_: Exception) {
        }
    }

    private fun waitForServerThenLoad() {
        thread(name = "bot-wait") {
            val t0 = System.currentTimeMillis()
            while (true) {
                val err = BotState.error
                if (err != null) {
                    ui.post {
                        status.text = "Bot başlatılamadı. Bu ekranın görüntüsünü gönderin:\n\n$err"
                    }
                    return@thread
                }
                if (ready()) break
                if (System.currentTimeMillis() - t0 > 240_000) {
                    ui.post { status.text = "Bot 4 dakikada açılamadı. Uygulamayı kapatıp yeniden açın." }
                    return@thread
                }
                Thread.sleep(700)
            }
            login()
            ui.post {
                status.visibility = View.GONE
                web.loadUrl("$base/")
            }
        }
    }

    private fun setupWebView() {
        CookieManager.getInstance().setAcceptCookie(true)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false   // alarm sesi
            textZoom = 100
        }
        web.setBackgroundColor(0xFF0B0F17.toInt())
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: android.webkit.WebResourceRequest): Boolean {
                val u = request.url
                if (u.host == "127.0.0.1") return false
                try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (_: Exception) {}   // haber bağlantıları tarayıcıda açılır
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onJsConfirm(view: WebView, url: String, message: String, result: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setPositiveButton("Tamam") { _, _ -> result.confirm() }
                    .setNegativeButton("İptal") { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }

            override fun onJsAlert(view: WebView, url: String, message: String, result: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setPositiveButton("Tamam") { _, _ -> result.confirm() }
                    .setOnCancelListener { result.confirm() }
                    .show()
                return true
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else moveTaskToBack(true)   // kapatma: bot arka planda çalışmaya devam eder
    }
}
