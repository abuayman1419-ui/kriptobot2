"""Long/Short puanlama. Her bileşen -1..+1 arası 'bias' üretir; puan = ağırlık*(0.5 ± 0.5*bias).
Yalnızca KAPANMIŞ mumlar verilmelidir. Skor başarı olasılığı DEĞİLDİR, sadece sıralama ölçüsüdür."""
import numpy as np
from indicators import (adx, atr, bollinger, ema, last, macd, obv, rsi, vwap)
from patterns import detect


def clip(x, a=-1.0, b=1.0):
    return float(max(a, min(b, x)))


def btc_bias(d5, d15):
    """BTC yönü: 15m EMA dizilimi + 5m hareketi."""
    e9, e20, e50 = (last(ema(d15.c, n)) for n in (9, 20, 50))
    stack = 1 if e9 > e20 > e50 else -1 if e9 < e20 < e50 else 0.3 * np.sign(e9 - e20)
    ret = d5.c.iloc[-1] / d5.c.iloc[-7] - 1
    return clip(0.6 * stack + 0.4 * clip(ret / 0.01))


def regime(btc_b, d5):
    rng = (d5.h.iloc[-12:].max() - d5.l.iloc[-12:].min()) / d5.c.iloc[-1]
    if rng > 0.02:
        return "High Volatility / Unstable"
    return ("Strong Bullish" if btc_b > 0.6 else "Bullish" if btc_b > 0.2 else
            "Strong Bearish" if btc_b < -0.6 else "Bearish" if btc_b < -0.2 else "Neutral")


def analyze(sym, f, depth, oi_chg, funding, b_bias, qv24, cfg, news_bias=0.0, news_flag=False):
    d5, d15 = f["5m"], f["15m"]
    c5, c15 = d5.c, d15.c
    price = float(c5.iloc[-1])
    a5 = last(atr(d5))
    for_, against = [], []

    # 1) Teknik (formasyon + EMA + MACD + VWAP)
    e9, e20, e50 = (last(ema(c15, n)) for n in (9, 20, 50))
    ema_b = 1 if e9 > e20 > e50 else -1 if e9 < e20 < e50 else 0.3 * np.sign(e9 - e20)
    macd_b = 0.5 * np.sign(last(macd(c5)[2])) + 0.5 * np.sign(last(macd(c15)[2]))
    pats = detect(d5)
    pat_b = clip(sum(p["bias"] for p in pats))
    vw_b = 1 if c15.iloc[-1] > last(vwap(d15)) else -1
    tech = clip(0.35 * ema_b + 0.25 * macd_b + 0.25 * pat_b + 0.15 * vw_b)

    # 2) Hacim ve para akışı
    vr = float(d5.v.iloc[-1] / max(d5.v.iloc[-21:-1].mean(), 1e-12))
    tbr = float(d5.tb.iloc[-3:].sum() / max(d5.v.iloc[-3:].sum(), 1e-12))
    o_sl = np.sign(last(obv(d5)) - float(obv(d5).iloc[-10]))
    flow = clip(clip((tbr - 0.5) * 6) * (0.6 + 0.4 * min(vr, 3) / 3) + 0.2 * o_sl)

    # 3) Trend / momentum
    adx_v, pdi, mdi = (last(x) for x in adx(d15))
    r15, r5 = last(rsi(c15)), last(rsi(c5))
    trend = clip(min(adx_v / 40, 1) * np.sign(pdi - mdi) * 0.7 + 0.3 * clip((r15 - 50) / 20))

    # 4) Order book
    spread, ob = None, 0.0
    if depth and depth.get("bids") and depth.get("asks"):
        bv = sum(float(p) * float(q) for p, q in depth["bids"])
        av = sum(float(p) * float(q) for p, q in depth["asks"])
        ob = clip((bv - av) / max(bv + av, 1e-12) * 2)
        bid, ask = float(depth["bids"][0][0]), float(depth["asks"][0][0])
        spread = (ask - bid) / bid * 100

    # 5) Haber (news.py bağlanana kadar nötr)
    news = clip(news_bias)

    # 6) BTC
    btc = 0.0 if sym == "BTCUSDT" else b_bias

    # 7) OI + Funding
    ret30 = float(c5.iloc[-1] / c5.iloc[-7] - 1)
    oif = 0.0
    if oi_chg is not None and abs(oi_chg) > 0.005:
        if oi_chg > 0:
            oif = 0.7 if ret30 > 0 else -0.7
        else:
            oif = -0.2 if ret30 > 0 else 0.2
    if funding is not None:
        oif += -0.4 if funding > 0.0005 else 0.4 if funding < -0.0005 else 0
    oif = clip(oif)

    biases = {"technical": tech, "flow": flow, "trend": trend, "orderbook": ob,
              "news": news, "btc": btc, "oi_funding": oif}
    W = cfg.weights
    long_s = sum(W[k] * (0.5 + 0.5 * b) for k, b in biases.items())
    short_s = sum(W[k] * (0.5 - 0.5 * b) for k, b in biases.items())
    side = "LONG" if long_s >= short_s else "SHORT"
    sgn = 1 if side == "LONG" else -1
    score, opp = (long_s, short_s) if side == "LONG" else (short_s, long_s)

    names = {"technical": "Teknik/formasyon", "flow": "Hacim ve para akışı", "trend": "Trend/momentum",
             "orderbook": "Order book", "news": "Haber", "btc": "BTC uyumu", "oi_funding": "OI/Funding"}
    for k, b in biases.items():
        if k == "news":
            continue
        (for_ if b * sgn > 0.25 else against if b * sgn < -0.25 else []).append(names[k])

    # Filtreler
    sl_dist = cfg.sl_atr_mult * a5
    sl_pct = sl_dist / price * 100
    filters = {
        "Spread uygun": spread is None or spread <= cfg.max_spread_pct,
        "Likidite yeterli": qv24 >= cfg.min_trade_qv24,
        "Giriş kaçmamış": abs(price - last(ema(c5, 20))) <= cfg.max_chase_atr * a5,
        "Stop mesafesi makul": cfg.min_sl_pct <= sl_pct <= cfg.max_sl_pct,
        "RSI aşırı değil": not ((side == "LONG" and r5 > 80) or (side == "SHORT" and r5 < 20)),
        "BTC engellemiyor": not (sym != "BTCUSDT" and ((side == "LONG" and b_bias < -0.5) or (side == "SHORT" and b_bias > 0.5))),
        "Karşı yön zayıf": opp <= cfg.opposite_max,
        "Kritik haber yok": not news_flag,
    }
    passed = all(filters.values())
    ok = passed and score >= cfg.entry_threshold
    signal = ("BUY" if side == "LONG" else "SELL") if ok else "WAIT"

    if side == "LONG":
        sl, tps = price - sl_dist, [price + r * sl_dist for r in cfg.tp_r]
        invalid = f"{sl:.6g} altında kapanış"
    else:
        sl, tps = price + sl_dist, [price - r * sl_dist for r in cfg.tp_r]
        invalid = f"{sl:.6g} üstünde kapanış"

    bb_u, bb_m, bb_l = bollinger(c5)
    bbw = (bb_u - bb_l) / bb_m
    squeeze = bool(last(bbw) < 0.6 * float(bbw.iloc[-50:].median())) if len(bbw) >= 50 else False

    why = f"{sym}: {side} yönü {score:.0f}/100 (karşı yön {opp:.0f}). "
    if for_:
        why += "Destekleyen: " + ", ".join(for_) + ". "
    if against:
        why += "Karşı çıkan: " + ", ".join(against) + ". "
    if abs(news) > 0.05:
        why += f"Haber etkisi: {'olumlu' if news > 0 else 'olumsuz'}. "
    if pats:
        why += "Formasyon: " + ", ".join(p["name"] for p in pats if p["name"] != "Doji") + ". "
    failed = [k for k, v in filters.items() if not v]
    if failed:
        why += "Filtre engeli: " + ", ".join(failed) + ". "
    if signal == "WAIT":
        why += "Uygun fırsat yok, beklenmeli."

    return {
        "symbol": sym, "price": price, "side": side, "signal": signal,
        "long": round(long_s, 1), "short": round(short_s, 1), "score": round(score, 1),
        "biases": {k: round(v, 2) for k, v in biases.items()},
        "filters": filters, "patterns": [p["name"] for p in pats],
        "atr": a5, "sl": sl, "tps": tps, "rr": cfg.tp_r[-1], "invalid": invalid,
        "vol_ratio": round(vr, 2), "taker_buy": round(tbr, 2),
        "oi_change_pct": None if oi_chg is None else round(oi_chg * 100, 2),
        "funding": funding, "spread_pct": None if spread is None else round(spread, 4),
        "rsi5": round(r5, 1), "squeeze": squeeze, "note": why.strip(), "qv24": qv24,
    }
