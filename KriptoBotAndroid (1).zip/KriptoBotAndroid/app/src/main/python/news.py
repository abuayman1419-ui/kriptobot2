"""Canlı haber akışı (anahtarsız kaynaklar: RSS + Binance duyuruları). Her kaynak bağımsız hata verir.
Haberler tekilleştirilir, yayın zamanı ile ilk görülme zamanı ayrı tutulur, 48 saatten eskiler gösterilmez.
Sınıflar: KRİTİK / NEGATİF / POZİTİF / NÖTR + önemli/önemsiz. Anahtar kelime kurallarıdır, yatırım tavsiyesi değildir."""
import asyncio
import html
import re
import time
import xml.etree.ElementTree as ET
from email.utils import parsedate_to_datetime


RSS = {"CoinDesk": "https://www.coindesk.com/arc/outboundfeeds/rss/",
       "Cointelegraph": "https://cointelegraph.com/rss",
       "Decrypt": "https://decrypt.co/feed",
       "The Block": "https://www.theblock.co/rss.xml"}
BIN = "https://www.binance.com/bapi/composite/v1/public/cms/article/list/query?type=1&pageNo=1&pageSize=15&catalogId="
BIN_CATS = {48: "Binance Listeleme", 161: "Binance Delisting", 49: "Binance Duyuru"}
UA = {"User-Agent": "Mozilla/5.0 (CryptoAITerminal)"}

CRIT = r"hack|exploit|drain|stolen|theft|delist|rug ?pull|insolven|bankrupt|de-?peg|emergency|halt|suspend|sues|lawsuit|indict|arrest|seiz|liquidat|collapse|outage|\bbans?\b|banned|breach|attack"
NEG = r"fall|drop|plunge|slump|sell-?off|dump|outflow|declin|fear|bearish|reject|fine[ds]?\b|investigat|warn|loss|tumbl|slide|slash|crackdown|concern|risk|pressure"
POS = r"approv|inflow|surge|rall(y|ies)|record|soar|jump|gain|bullish|partnership|launch|upgrade|adopt|integrat|will list|lists\b|listing|buy|accumulat|breakout|rebound|recover|milestone|win"
MACRO = r"\bfed\b|fomc|powell|\bcpi\b|\bppi\b|inflation|rate (cut|hike)|interest rate|\bsec\b|cftc|\betf|binance|tariff|treasury|stablecoin|tether|blackrock|strategy|whale|jobs report|nonfarm"
ALARM = r"fomc|\bcpi\b|rate (cut|hike|decision)|fed (cuts|hikes|holds|raises)|etf (approv|reject)|sec (sues|approv|reject)|hack|exploit|drain|delist|\bbans?\b|bankrupt|insolven|de-?peg|halt|suspend|emergency|crash|plunge|liquidat|billion"
IMPACT = {"KRİTİK": "Ani ve sert fiyat hareketi riski; oynaklık artabilir", "NEGATİF": "Kısa vadede satış baskısı oluşturabilir",
          "POZİTİF": "Kısa vadede alım ilgisini artırabilir", "NÖTR": "Belirgin bir fiyat etkisi beklenmiyor"}
TOP = {"BTC", "ETH", "BNB", "SOL", "XRP"}
NAMES = {"bitcoin": "BTC", "ethereum": "ETH", "ether ": "ETH", "solana": "SOL", "ripple": "XRP", "dogecoin": "DOGE",
         "cardano": "ADA", "avalanche": "AVAX", "chainlink": "LINK", "polkadot": "DOT", "litecoin": "LTC",
         "tron": "TRX", "toncoin": "TON", "aptos": "APT", "near protocol": "NEAR", "shiba": "SHIB",
         "pepe": "PEPE", "uniswap": "UNI", "arbitrum": "ARB", "polygon": "POL", "sui ": "SUI", "bnb": "BNB"}
STOP = {"USD", "ETF", "SEC", "CEO", "FED", "NFT", "CPI", "PPI", "ATH", "DEX", "DAO", "USA", "THE", "AND", "FOR",
        "NEW", "ALL", "ONE", "CFO", "IPO", "GDP", "FBI", "DOJ", "EU", "UK", "AI"}


def classify(text, source=""):
    t = text.lower()
    crit, neg, pos = (len(re.findall(p, t)) for p in (CRIT, NEG, POS))
    if "delist" in t or source == "Binance Delisting":
        level = "KRİTİK"
    elif crit and pos <= crit:
        level = "KRİTİK"
    elif pos > neg:
        level = "POZİTİF"
    elif neg > pos:
        level = "NEGATİF"
    else:
        level = "NÖTR"
    return level, bool(crit), bool(re.search(MACRO, t))


class NewsFeed:
    def __init__(self):
        self.items = {}
        self.status = {}
        self.universe = set()      # {"BTC", "ETH", ...} (taban varlıklar)
        self.s = None

    # ---------- eşleme ----------
    def coins(self, title):
        out = {v for k, v in NAMES.items() if k in title.lower() + " "}
        out |= {w for w in re.findall(r"\b[A-Z]{2,10}\b", title) if w not in STOP}
        return sorted(c for c in out if c in self.universe)

    def _add(self, title, link, source, pub, desc=""):
        title = html.unescape(re.sub(r"\s+", " ", title)).strip()
        if not title:
            return
        now = time.time()
        pub = pub or now
        if now - pub > 48 * 3600:
            return
        key = re.sub(r"[^a-z0-9]", "", title.lower())[:60]
        if key in self.items:
            it = self.items[key]
            if source not in it["sources"]:
                it["sources"].append(source)
            return
        level, crit, macro = classify(title + " " + desc[:200], source)
        coins = self.coins(title)
        important = crit or macro or level == "KRİTİK" or (bool(set(coins) & TOP) and level != "NÖTR") \
            or source.startswith("Binance")
        alarm = bool(important and (level == "KRİTİK" or re.search(ALARM, (title + " " + desc[:200]).lower())))
        low = (title + " " + source).lower()
        imp = IMPACT[level]
        if "delist" in low:
            imp = "Delisting duyuruları genellikle sert satış ve yüksek oynaklık getirir"
        elif source == "Binance Listeleme":
            imp = "Yeni listeleme duyuruları ilk dakikalarda sert yükseliş ve yüksek oynaklık yaratabilir"
        imp += f". Etkilenebilecek: {', '.join(coins) or 'genel piyasa'}. " + ("Etki saatler içinde görülebilir." if macro or alarm else "Etki birkaç saat–gün sürebilir.")
        bias = {"POZİTİF": 0.6, "NEGATİF": -0.6, "KRİTİK": -1.0, "NÖTR": 0.0}[level]
        if level == "KRİTİK" and "list" in title.lower() and "delist" not in title.lower():
            bias = 0.6
        self.items[key] = {"id": key, "title": title, "alarm": alarm, "impact_tr": imp, "tr_try": 0, "link": link, "sources": [source], "pub": pub, "first_seen": now,
                           "level": level, "important": important, "coins": coins,
                           "bias": bias * (1.0 if important else 0.4)}

    # ---------- kaynaklar ----------
    async def _get(self, url):
        async with self.s.get(url, headers=UA) as r:
            r.raise_for_status()
            return await r.text()

    async def _rss(self, name, url):
        root = ET.fromstring(await self._get(url))
        n = 0
        for it in root.iter("item"):
            title = (it.findtext("title") or "").strip()
            link = (it.findtext("link") or "").strip()
            desc = re.sub(r"<[^>]+>", " ", html.unescape(it.findtext("description") or ""))
            try:
                pub = parsedate_to_datetime(it.findtext("pubDate")).timestamp()
            except Exception:
                pub = None
            self._add(title, link, name, pub, desc)
            n += 1
        return n

    async def _binance(self, cat, name):
        async with self.s.get(BIN + str(cat), headers=UA) as r:
            r.raise_for_status()
            d = await r.json()
        n = 0
        for c in d["data"]["catalogs"]:
            for a in c.get("articles", []):
                self._add(a["title"], f"https://www.binance.com/en/support/announcement/{a['code']}", name,
                          a["releaseDate"] / 1000)
                n += 1
        return n

    async def refresh(self):
        jobs = [(n, self._rss(n, u)) for n, u in RSS.items()] + [(n, self._binance(c, n)) for c, n in BIN_CATS.items()]
        res = await asyncio.gather(*(j for _, j in jobs), return_exceptions=True)
        for (n, _), r in zip(jobs, res):
            self.status[n] = {"ok": not isinstance(r, Exception), "ts": time.time(),
                              "n": r if isinstance(r, int) else 0,
                              "err": "" if not isinstance(r, Exception) else f"{type(r).__name__}: {str(r)[:80]}"}
        cut = time.time() - 48 * 3600
        for k in [k for k, v in self.items.items() if v["pub"] < cut]:
            del self.items[k]

    async def _tr(self, text):
        async with self.s.get("https://translate.googleapis.com/translate_a/single", headers=UA,
                              params={"client": "gtx", "sl": "en", "tl": "tr", "dt": "t", "q": text}) as r:
            r.raise_for_status()
            d = await r.json(content_type=None)
        return "".join(seg[0] for seg in d[0] if seg and seg[0])

    async def translate_pending(self):
        todo = [i for i in self.items.values() if "title_tr" not in i and i["tr_try"] < 3][:25]
        sem = asyncio.Semaphore(4)

        async def one(i):
            async with sem:
                try:
                    i["title_tr"] = await self._tr(i["title"])
                except Exception as e:
                    i["tr_try"] += 1
                    self.status["Çeviri"] = {"ok": False, "ts": time.time(), "n": 0, "err": f"{type(e).__name__}: {str(e)[:60]}"}
        await asyncio.gather(*(one(i) for i in todo))
        if todo and all("title_tr" in i for i in todo):
            self.status["Çeviri"] = {"ok": True, "ts": time.time(), "n": len(todo), "err": ""}

    async def run(self):
        import aiohttp
        self.s = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=15))
        while True:
            try:
                await self.refresh()
                await self.translate_pending()
            except Exception as e:
                self.status["_loop"] = {"ok": False, "err": str(e)[:80], "ts": time.time(), "n": 0}
            await asyncio.sleep(60)

    # ---------- dışarıya ----------
    def listing(self, n=60):
        now = time.time()
        rows = sorted(self.items.values(), key=lambda x: -x["pub"])[:n]
        return [dict(r, age_min=int((now - r["pub"]) / 60)) for r in rows]

    def for_symbol(self, sym, hours=2):
        base = sym[:-4] if sym.endswith("USDT") else sym
        cut = time.time() - hours * 3600
        return [i for i in self.items.values() if base in i["coins"] and i["pub"] >= cut]

    def bias_for(self, sym):
        v = sum(i["bias"] for i in self.for_symbol(sym))
        return max(-1.0, min(1.0, v))

    def critical_for(self, sym):
        return any(i["level"] == "KRİTİK" and i["bias"] < 0 for i in self.for_symbol(sym))
